package com.usecase.circuitbreakerusercase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitBreakerUserCaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CircuitBreakerUserCaseApplication.class, args);
    }

}
