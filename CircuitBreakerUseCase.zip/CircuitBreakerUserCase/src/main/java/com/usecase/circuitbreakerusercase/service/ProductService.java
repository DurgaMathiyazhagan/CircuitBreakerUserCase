package com.usecase.circuitbreakerusercase.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    private static final String PRODUCT_SERVICE = "productService";

    @Autowired
    private ExternalService externalService;

    @CircuitBreaker(name = PRODUCT_SERVICE, fallbackMethod = "fallbackResponse")
    public String getProductDetails() {
        return externalService.callExternalService();
    }

    // Fallback method for Circuit Breaker
    public String fallbackResponse(Exception ex) {
        return "Default Product Details (Fallback Response)";
    }
}