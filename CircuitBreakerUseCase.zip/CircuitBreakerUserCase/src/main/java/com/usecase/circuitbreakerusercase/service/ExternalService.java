package com.usecase.circuitbreakerusercase.service;

import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class ExternalService {

    public String callExternalService() {
        // Simulating a 50% failure rate
        if (new Random().nextBoolean()) {
            throw new RuntimeException("External Service is down!");
        }
        return "External Service Response";
    }
}