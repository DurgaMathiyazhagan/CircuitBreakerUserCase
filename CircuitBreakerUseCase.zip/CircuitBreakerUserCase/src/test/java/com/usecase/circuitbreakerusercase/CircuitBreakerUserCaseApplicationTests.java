package com.usecase.circuitbreakerusercase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerUserCaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
